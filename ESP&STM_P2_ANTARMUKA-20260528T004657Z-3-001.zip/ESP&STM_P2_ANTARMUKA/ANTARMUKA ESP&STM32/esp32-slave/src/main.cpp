#include <Arduino.h>
#include <driver/spi_slave.h>

static constexpr gpio_num_t PIN_SPI_MISO = GPIO_NUM_19;
static constexpr gpio_num_t PIN_SPI_MOSI = GPIO_NUM_23;
static constexpr gpio_num_t PIN_SPI_SCLK = GPIO_NUM_18;
static constexpr gpio_num_t PIN_SPI_CS = GPIO_NUM_5;

static uint8_t txBuffer[4] = {'E', 'S', 'P', '0'};
static uint8_t rxBuffer[4] = {0};
static uint32_t transactionCount = 0;

void printPacket(const char *label, const uint8_t *data, size_t length) {
  Serial.print(label);
  Serial.print(": ");
  for (size_t i = 0; i < length; ++i) {
    if (data[i] < 16) {
      Serial.print('0');
    }
    Serial.print(data[i], HEX);
    if (i + 1 < length) {
      Serial.print(' ');
    }
  }
  Serial.println();
}

void prepareResponse(const uint8_t *received, size_t length) {
  txBuffer[0] = received[0] ^ 0xFF;
  txBuffer[1] = received[1] ^ 0xFF;
  txBuffer[2] = received[2] ^ 0xFF;
  txBuffer[3] = received[3] ^ 0xFF;

  if (length < sizeof(txBuffer)) {
    for (size_t i = length; i < sizeof(txBuffer); ++i) {
      txBuffer[i] = 0x00;
    }
  }
}

void setup() {
  Serial.begin(115200);
  delay(1000);

  spi_bus_config_t buscfg = {};
  buscfg.miso_io_num = PIN_SPI_MISO;
  buscfg.mosi_io_num = PIN_SPI_MOSI;
  buscfg.sclk_io_num = PIN_SPI_SCLK;
  buscfg.quadwp_io_num = -1;
  buscfg.quadhd_io_num = -1;
  buscfg.max_transfer_sz = 4;

  spi_slave_interface_config_t slvcfg = {};
  slvcfg.spics_io_num = PIN_SPI_CS;
  slvcfg.flags = 0;
  slvcfg.queue_size = 1;
  slvcfg.mode = 0;

  esp_err_t ret = spi_slave_initialize(VSPI_HOST, &buscfg, &slvcfg, SPI_DMA_CH_AUTO);
  if (ret != ESP_OK) {
    Serial.print("Gagal inisialisasi SPI slave, error = ");
    Serial.println(static_cast<int>(ret));
    while (true) {
      delay(1000);
    }
  }

  Serial.println("=== ESP32 SPI SLAVE ===");
  Serial.println("Status: siap menerima data dari STM32");
}

void loop() {
  spi_slave_transaction_t trans = {};
  trans.length = sizeof(rxBuffer) * 8;
  trans.tx_buffer = txBuffer;
  trans.rx_buffer = rxBuffer;

  esp_err_t ret = spi_slave_transmit(VSPI_HOST, &trans, portMAX_DELAY);
  if (ret != ESP_OK) {
    Serial.print("Transaksi SPI gagal, error = ");
    Serial.println(static_cast<int>(ret));
    return;
  }

  ++transactionCount;

  Serial.println("--- Data Masuk SPI ---");
  Serial.print("Transaksi ke-      : ");
  Serial.println(transactionCount);
  printPacket("Data diterima", rxBuffer, sizeof(rxBuffer));

  prepareResponse(rxBuffer, sizeof(rxBuffer));
  printPacket("Balasan berikutnya", txBuffer, sizeof(txBuffer));
  Serial.println();
}
