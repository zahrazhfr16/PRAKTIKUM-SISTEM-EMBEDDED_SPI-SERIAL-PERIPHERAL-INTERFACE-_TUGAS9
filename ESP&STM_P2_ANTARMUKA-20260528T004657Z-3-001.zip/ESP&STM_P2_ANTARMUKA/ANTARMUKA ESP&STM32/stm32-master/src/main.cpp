#include <Arduino.h>
#include <SPI.h>

static const uint8_t PIN_SPI_CS = PA4;
static const SPISettings SPI_CONFIG(1000000, MSBFIRST, SPI_MODE0);

uint32_t counter = 0;

void printPacket(const char *label, const uint8_t *data, size_t length) {
  Serial.print(label);
  Serial.print(": ");
  for (size_t i = 0; i < length; ++i) {
    if (data[i] < 16) {
      Serial.print('0');
    }
    Serial.print(data[i], HEX);
    if (i + 1 < length) {
      Serial.print(' ');
    }
  }
  Serial.println();
}

void setup() {
  Serial.begin(115200);
  delay(1000);

  pinMode(PIN_SPI_CS, OUTPUT);
  digitalWrite(PIN_SPI_CS, HIGH);

  SPI.begin();

  Serial.println("=== STM32 SPI MASTER ===");
  Serial.println("Status: siap komunikasi dengan ESP32");
}

void loop() {
  uint8_t txBuffer[4];
  uint8_t rxBuffer[4];

  // Memecah uint32_t menjadi 4 byte (Big Endian)
  txBuffer[0] = (counter >> 24) & 0xFF;
  txBuffer[1] = (counter >> 16) & 0xFF;
  txBuffer[2] = (counter >> 8) & 0xFF;
  txBuffer[3] = counter & 0xFF;

  memset(rxBuffer, 0, sizeof(rxBuffer));

  SPI.beginTransaction(SPI_CONFIG);
  digitalWrite(PIN_SPI_CS, LOW);

  for (size_t i = 0; i < sizeof(txBuffer); ++i) {
    rxBuffer[i] = SPI.transfer(txBuffer[i]);
  }

  digitalWrite(PIN_SPI_CS, HIGH);
  SPI.endTransaction();

  Serial.println("--- Pengiriman SPI ---");
  Serial.print("Counter terkirim : ");
  Serial.println(counter);
  printPacket("Data TX", txBuffer, sizeof(txBuffer));
  printPacket("Data RX", rxBuffer, sizeof(rxBuffer));
  Serial.println();

  ++counter;
  delay(1000);
}