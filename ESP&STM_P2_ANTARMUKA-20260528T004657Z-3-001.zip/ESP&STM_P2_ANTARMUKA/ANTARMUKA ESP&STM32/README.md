# SPI STM32F103C8T6 - ESP32

Proyek ini berisi dua aplikasi PlatformIO:

- `stm32-master`: STM32F103C8T6 sebagai SPI master
- `esp32-slave`: ESP32 sebagai SPI slave

## Wiring

Gunakan tegangan logika 3.3V dan sambungkan ground bersama.

| STM32F103C8T6 | ESP32 |
| --- | --- |
| PA5 (SCK) | GPIO18 (SCK) |
| PA6 (MISO) | GPIO19 (MISO) |
| PA7 (MOSI) | GPIO23 (MOSI) |
| PA4 (NSS/CS) | GPIO5 (CS) |
| GND | GND |

## Cara kerja

- STM32 mengirim 4 byte data setiap 1 detik.
- ESP32 menerima data itu, lalu menyiapkan respons untuk transaksi berikutnya.
- Karena SPI bersifat full-duplex, data balasan yang diterima master pada transaksi pertama bisa berupa data awal atau respons transaksi sebelumnya.

## Upload

1. Buka folder `stm32-master` di PlatformIO dan upload ke STM32.
2. Buka folder `esp32-slave` di PlatformIO dan upload ke ESP32.
3. Buka Serial Monitor pada kedua board dengan baud `115200`.

Jika Anda memakai ST-Link untuk STM32, pastikan konfigurasi upload sesuai dengan alat yang Anda pakai.
