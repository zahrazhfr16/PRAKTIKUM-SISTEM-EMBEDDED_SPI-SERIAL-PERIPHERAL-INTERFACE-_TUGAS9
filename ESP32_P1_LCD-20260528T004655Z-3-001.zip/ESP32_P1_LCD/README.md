# ESP32 LCD TFT SPI - ST7735 Display Project

Program untuk menampilkan grafis warna-warni di LCD TFT SPI 1.8" dengan microcontroller ESP32 menggunakan PlatformIO.

## Hardware Requirements

### Komponen yang Dibutuhkan:
- **ESP32 Development Board** (DOIT DevKit v1 atau sejenis)
- **LCD TFT SPI 1.8"** dengan chip ST7735
- **Kabel Dupont** untuk koneksi
- **Power Supply** 5V

## Koneksi Pin ESP32 ke LCD TFT

| LCD Pin | ESP32 Pin | Deskripsi |
|---------|-----------|-----------|
| VCC     | 5V        | Power Supply |
| GND     | GND       | Ground |
| CS      | GPIO 5    | Chip Select |
| RST     | GPIO 2    | Reset |
| DC      | GPIO 4    | Data/Command |
| MOSI    | GPIO 23   | SPI Data Out |
| SCLK    | GPIO 18   | SPI Clock |
| MISO    | GPIO 19   | SPI Data In (optional) |

## Skema Koneksi

```
ESP32 DevKit           ST7735 LCD
─────────────          ──────────
GPIO 5  (CS)   ────→   CS
GPIO 2  (RST)  ────→   RST
GPIO 4  (DC)   ────→   DC
GPIO 23 (MOSI) ────→   SDA
GPIO 18 (SCLK) ────→   SCL
GND            ────→   GND
5V             ────→   VCC
```

## Instalasi dan Setup

### 1. Install PlatformIO
- Download dan install Visual Studio Code
- Install extension PlatformIO IDE di VS Code

### 2. Clone/Copy Project
- Copy folder project ini ke direktori kerja Anda

### 3. Build dan Upload
```bash
# Buka terminal di folder project
# Build project
platformio run

# Upload ke ESP32
platformio run --target upload

# Monitoring output serial
platformio device monitor
```

Atau gunakan fitur bawaan PlatformIO di VS Code:
- Build: Klik tombol Build di bagian bawah
- Upload: Klik tombol Upload
- Monitor: Klik tombol Serial Monitor

## Fitur Program

Program menampilkan berbagai pola dan grafis menarik:

1. **Splash Screen** - Layar pembuka dengan judul
2. **Rainbow Colors** - Pita pelangi dengan 6 warna utama
3. **Colorful Circles** - Lingkaran-lingkaran berwarna
4. **Color Gradient** - Gradasi warna dari merah ke biru
5. **Geometric Shapes** - Bentuk geometri (persegi, lingkaran, segitiga)
6. **Moving Animation** - Animasi lingkaran yang bergerak
7. **Color Grid** - Grid kotak dengan berbagai warna
8. **Display Info** - Informasi spesifikasi display

Semua pola ditampilkan berulang terus-menerus.

## Library yang Digunakan

- **Adafruit ST7735 and ST7789 Library** - Driver untuk display ST7735
- **Adafruit GFX Library** - Library grafis
- **Adafruit BusIO** - Library komunikasi bus

Library secara otomatis diinstall saat build project.

## Troubleshooting

### Display tidak menyala atau menampilkan noise
1. Periksa koneksi pin kembali sesuai diagram
2. Pastikan power supply cukup (minimal 1A untuk 5V)
3. Coba ubah nilai INITR di main.cpp:
   - `INITR_BLACKTAB` (default)
   - `INITR_REDTAB`
   - `INITR_GREENTAB`

### Upload gagal
1. Pastikan port COM sudah terpilih dengan benar
2. Tekan tombol BOOT di ESP32 selama proses upload
3. Pastikan driver CH340 sudah terinstall (jika menggunakan DOIT DevKit)

### Serial Monitor tidak menampilkan output
1. Pilih baud rate 115200 di serial monitor
2. Tekan tombol EN (Reset) di ESP32

## Modifikasi dan Pengembangan

### Mengubah Pin
Edit nilai konstanta di awal `main.cpp`:
```cpp
#define TFT_CS    5      // Ubah pin sesuai kebutuhan
#define TFT_RST   17
#define TFT_DC    16
```

### Menambah Animasi
Buat fungsi baru seperti contoh yang ada:
```cpp
void displayCustom() {
  tft.fillScreen(ST7735_BLACK);
  // Tambahkan kode grafis Anda di sini
  delay(2000);
}
```

Kemudian panggil di dalam fungsi `loop()`:
```cpp
displayCustom();
```

### Warna Tersedia
- `ST7735_BLACK`, `ST7735_WHITE`
- `ST7735_RED`, `ST7735_GREEN`, `ST7735_BLUE`
- `ST7735_CYAN`, `ST7735_MAGENTA`, `ST7735_YELLOW`
- Dan banyak warna lainnya

## Referensi Dokumentasi

- [Adafruit ST7735 Library](https://github.com/adafruit/Adafruit-ST7735-Library)
- [Adafruit GFX Library](https://github.com/adafruit/Adafruit-GFX-Library)
- [PlatformIO Documentation](https://docs.platformio.org)
- [ESP32 Documentation](https://docs.espressif.com/projects/esp-idf/en/latest/esp32/)

## Lisensi

Proyek ini dibuat untuk tujuan pendidikan dan pembelajaran modul praktikum.

---

**Happy Coding! 🎨**
